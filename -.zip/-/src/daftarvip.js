const daftarvip = (prefix) => { 
	return `
*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/628165466368 atau ketik *${prefix}owner* `
}
exports.daftarvip = daftarvip