const wibu = (prefix, pushname) => {
	return ` 

_*Wibu*_
╰─⊱ *${prefix}sarananime*
╰─⊱ *${prefix}kiss*
╰─⊱ *${prefix}peluk*
╰─⊱ *${prefix}randomcry*
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}nakonime*
╰─⊱ *${prefix}nekonime2*
╰─⊱ *${prefix}wait*
╰─⊱ *${prefix}wibu*
╰─⊱ *${prefix}pokemon*
╰─⊱ *${prefix}naruto*
╰─⊱ *${prefix}hinata*
╰─⊱ *${prefix}sasuke*
╰─⊱ *${prefix}sakura*
╰─⊱ *${prefix}boruto*
╰─⊱ *${prefix}minato*
╰─⊱ *${prefix}loli*
╰─⊱ *${prefix}loli2*
╰─⊱ *${prefix}rize*
╰─⊱ *${prefix}akira*
╰─⊱ *${prefix}itori*
╰─⊱ *${prefix}kurumi*
└ *${prefix}miku*
`
}
exports.wibu = wibu